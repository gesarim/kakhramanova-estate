const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
const photoScenes = new Map();
let photoFrame = 0;
let photoResize;
const clamp = (value) => Math.max(0, Math.min(1, value));

function updatePhotoScenes() {
  let needsFrame = false;
  for (const state of photoScenes.values()) {
    state.current = reduce
      ? state.target
      : state.current + (state.target - state.current) * 0.085;
    if (Math.abs(state.current - state.target) < 0.001)
      state.current = state.target;
    else needsFrame = true;
    const p = state.current;
    const mobile = innerWidth < 701;
    state.photo.style.width = (mobile ? 80 + 20 * p : 54 + 46 * p) + "%";
    state.photo.style.height = 62 + 38 * p + "%";
    state.photo.style.borderRadius =
      (mobile ? 22 + 16 * (1 - p) : 32 + 24 * (1 - p)) + "px";
    state.image.style.transform = `scale(${1.12 - 0.12 * p})`;
  }
  photoFrame = needsFrame ? requestAnimationFrame(updatePhotoScenes) : 0;
}

function measurePhotoScenes() {
  for (const [scene, state] of photoScenes) {
    state.target = clamp(
      (innerHeight - scene.getBoundingClientRect().top) / (innerHeight * 1.05),
    );
  }
  if (!photoFrame) photoFrame = requestAnimationFrame(updatePhotoScenes);
}

function registerPhotoScenes() {
  photoResize ??= new ResizeObserver(measurePhotoScenes);
  for (const scene of photoScenes.keys()) {
    if (scene.isConnected) continue;
    photoResize.unobserve(scene);
    photoScenes.delete(scene);
  }
  document.querySelectorAll(".scene").forEach((scene) => {
    if (photoScenes.has(scene)) return;
    const photo = scene.querySelector(".expand-photo");
    const image = photo?.querySelector("img");
    if (!image) return;
    photoScenes.set(scene, { photo, image, current: 0, target: 0 });
    photoResize.observe(scene);
  });
  measurePhotoScenes();
}

registerPhotoScenes();
addEventListener("scroll", measurePhotoScenes, { passive: true });
addEventListener("resize", measurePhotoScenes, { passive: true });
addEventListener("photo-scenes:mount", registerPhotoScenes);
const menu = document.getElementById("menu");
const menuButton = document.getElementById("menuButton");
const menuAnchor = menuButton.closest(".menu-anchor");

function toggleMenu(open) {
  menuButton.setAttribute("aria-expanded", String(open));
  menu.inert = !open;
}

menuButton.addEventListener("click", () => {
  toggleMenu(menuButton.getAttribute("aria-expanded") !== "true");
});
menu.addEventListener("click", (event) => {
  if (event.target.closest("a")) toggleMenu(false);
});
document.addEventListener("pointerdown", (event) => {
  if (!menuAnchor.contains(event.target)) toggleMenu(false);
});
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !menu.inert) {
    toggleMenu(false);
    menuButton.focus();
  }
});
const scrollNav = document.getElementById("scrollNav");
const scrollConsult = document.getElementById("scrollConsult");
const hero = document.getElementById("home");
const scrollLinks = Array.from(scrollNav.querySelectorAll('a[href^="#"]'));
let activeLink;
let navigationFrame = 0;

function updateScrollNav() {
  navigationFrame = 0;
  const marker = Math.min(innerHeight * 0.27, 190);
  const heroIsVisible = hero.getBoundingClientRect().bottom > 65;
  scrollNav.inert = heroIsVisible;
  const contacts = document.getElementById("contacts");
  scrollConsult.inert =
    heroIsVisible ||
    (contacts && contacts.getBoundingClientRect().top < innerHeight * 0.72);

  // Sticky sections can stay near the top after the next section has passed it.
  let next = scrollLinks[0];
  for (const link of scrollLinks) {
    const section = document.getElementById(link.hash.slice(1));
    if (section && section.getBoundingClientRect().top <= marker) next = link;
  }
  if (next === activeLink) return;
  activeLink?.removeAttribute("aria-current");
  next.setAttribute("aria-current", "location");
  activeLink = next;

  const navBounds = scrollNav.getBoundingClientRect();
  const linkBounds = next.getBoundingClientRect();
  const gutter = 8;
  if (linkBounds.left < navBounds.left + gutter) {
    scrollNav.scrollBy({
      left: linkBounds.left - navBounds.left - gutter,
      behavior: reduce ? "instant" : "smooth",
    });
  } else if (linkBounds.right > navBounds.right - gutter) {
    scrollNav.scrollBy({
      left: linkBounds.right - navBounds.right + gutter,
      behavior: reduce ? "instant" : "smooth",
    });
  }
}

function scheduleScrollNav() {
  if (!navigationFrame)
    navigationFrame = requestAnimationFrame(updateScrollNav);
}

addEventListener("scroll", scheduleScrollNav, { passive: true });
addEventListener("resize", scheduleScrollNav);
addEventListener("load", scheduleScrollNav);
scheduleScrollNav();

// A single timeline runs after type and imagery are ready; no layout shifts.
async function revealHero() {
  const heroImage = document.querySelector(".hero-photo>img");
  await Promise.allSettled([document.fonts.ready, heroImage.decode()]);
  if (reduce) {
    document.documentElement.classList.remove("motion-ready");
    return;
  }
  const ease = "cubic-bezier(.22,1,.36,1)";
  const play = (el, frames, delay, duration = 1000) =>
    el.animate(frames, { duration, delay, easing: ease, fill: "both" });
  const fadeUp = [
    { opacity: 0, transform: "translate3d(0,18px,0)" },
    { opacity: 1, transform: "translate3d(0,0,0)" },
  ];
  play(
    document.querySelector(".hero-photo"),
    [
      { opacity: 0, transform: "translate3d(0,16px,0)" },
      { opacity: 1, transform: "translate3d(0,0,0)" },
    ],
    30,
    1200,
  );
  play(
    heroImage,
    [{ transform: "scale(1.065)" }, { transform: "scale(1)" }],
    30,
    1650,
  );
  play(document.querySelector(".logo"), fadeUp, 100, 1000);
  document
    .querySelectorAll("nav .square")
    .forEach((e, i) => play(e, fadeUp, 160 + i * 75, 900));
  document.querySelectorAll(".line-mask>span").forEach((e, i) =>
    play(
      e,
      [
        { opacity: 0, transform: "translate3d(0,110%,0)" },
        { opacity: 1, transform: "translate3d(0,0,0)" },
      ],
      130 + i * 120,
      1150,
    ),
  );
  document
    .querySelectorAll(".photo-copy p")
    .forEach((e, i) => play(e, fadeUp, 500 + i * 110, 1100));
  play(
    document.querySelector(".consult"),
    [
      { opacity: 0, clipPath: "inset(0 calc(100% - 45px) 0 0 round 50px)" },
      { opacity: 1, clipPath: "inset(0 0% 0 0 round 50px)" },
    ],
    230,
    1250,
  );
  play(
    document.querySelector(".consult-label"),
    [
      { opacity: 0, transform: "translateX(-12px)" },
      { opacity: 1, transform: "translateX(0)" },
    ],
    650,
    850,
  );
  play(document.querySelector(".select"), fadeUp, 470, 1100);
  play(document.querySelector(".developers-link"), fadeUp, 660, 1050);
}
startPreloader();
async function startPreloader() {
  const root = document.documentElement,
    overlay = document.getElementById("preloader"),
    main = document.querySelector("main");
  if (!overlay) {
    revealHero();
    return;
  }
  main.inert = true;
  const bar = overlay.querySelector('[role="progressbar"]'),
    fill = document.getElementById("preloaderFill"),
    percent = document.getElementById("preloaderPercent");
  let target = 0,
    displayed = 0,
    frameId,
    last = performance.now(),
    finished = false;
  const update = () => {
    const now = performance.now(),
      delta = Math.min(now - last, 64);
    last = now;
    displayed += (target - displayed) * (1 - Math.exp(-delta / 165));
    if (target === 100 && displayed > 99.65) displayed = 100;
    fill.style.transform = `scaleX(${displayed / 100})`;
    percent.textContent = Math.floor(displayed) + "%";
    bar.setAttribute("aria-valuenow", String(Math.floor(displayed)));
    if (!finished) frameId = requestAnimationFrame(update);
  };
  update();
  const track = (promise, weight) =>
    Promise.resolve(promise)
      .catch(() => {})
      .finally(() => {
        target = Math.min(100, target + weight);
      });
  const decode = (selector) => {
    const img = document.querySelector(selector);
    return img ? img.decode() : Promise.resolve();
  };
  try {
    const tasks = [
      track(document.fonts.load("400 16px SF"), 15),
      track(document.fonts.load("500 16px SF"), 15),
      track(document.fonts.load("600 16px SF"), 10),
      track(decode(".preloader-logo"), 10),
      track(decode(".hero-photo>img"), 30),
      track(decode(".expand-photo>img"), 20),
    ];
    await Promise.race([
      Promise.allSettled(tasks),
      new Promise((resolve) => setTimeout(resolve, 8000)),
    ]);
    target = 100;
    await new Promise((resolve) => {
      const check = () =>
        displayed >= 100 ? resolve() : requestAnimationFrame(check);
      check();
    });
    if (!reduce) await new Promise((resolve) => setTimeout(resolve, 180));
    revealHero();
    if (!reduce)
      await overlay.animate(
        [{ transform: "translateY(0)" }, { transform: "translateY(-102%)" }],
        {
          duration: 900,
          easing: "cubic-bezier(.76,0,.24,1)",
          fill: "forwards",
        },
      ).finished;
  } catch {
    document.documentElement.classList.remove("motion-ready");
  } finally {
    finished = true;
    cancelAnimationFrame(frameId);
    clearTimeout(window.loaderSafety);
    main.inert = false;
    root.classList.remove("is-loading");
    overlay.remove();
  }
}
