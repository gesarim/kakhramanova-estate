const scene=document.querySelector('.scene'),photo=document.querySelector('.expand-photo'),photoImg=photo.querySelector('img');const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;let current=0,target=0;const clamp=(v)=>Math.max(0,Math.min(1,v));function measure(){const r=scene.getBoundingClientRect();target=clamp((innerHeight-r.top)/(innerHeight*1.05));}function frame(){current+= (target-current)*.085;const p=reduce?target:current;photo.style.width=(innerWidth<701?80+20*p:54+46*p)+'%';photo.style.height=(62+38*p)+'%';photo.style.borderRadius=(innerWidth < 701 ? 22 + 16 * (1 - p) : 32 + 24 * (1 - p)) + 'px';photoImg.style.transform=`scale(${1.12-.12*p})`;requestAnimationFrame(frame)}addEventListener('scroll',measure,{passive:true});addEventListener('resize',measure);measure();frame();const menu = document.getElementById('menu');
const menuButton = document.getElementById('menuButton');
const menuAnchor = menuButton.closest('.menu-anchor');

function toggleMenu(open) {
  menuButton.setAttribute('aria-expanded', String(open));
  menu.inert = !open;
}

menuButton.addEventListener('click', () => {
  toggleMenu(menuButton.getAttribute('aria-expanded') !== 'true');
});
menu.addEventListener('click', (event) => {
  if (event.target.closest('a')) toggleMenu(false);
});
document.addEventListener('pointerdown', (event) => {
  if (!menuAnchor.contains(event.target)) toggleMenu(false);
});
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && !menu.inert) {
    toggleMenu(false);
    menuButton.focus();
  }
});
const scrollNav = document.getElementById('scrollNav');
const scrollConsult = document.getElementById('scrollConsult');
const hero = document.getElementById('home');
const scrollLinks = Array.from(menu.querySelectorAll('a'), (link) => link.cloneNode(true));
for (const [after, id, label] of [
  ['advantages', 'approach', 'Подход'],
  ['services', 'service', 'Сервис'],
  ['service', 'lifestyle', 'Выбор дома'],
  ['lifestyle', 'project-criteria', 'Проекты'],
  ['developers', 'questions', 'Вопросы'],
]) {
  const link = document.createElement('a');
  link.href = '#' + id;
  link.textContent = label;
  scrollLinks.splice(scrollLinks.findIndex((item) => item.hash === '#' + after) + 1, 0, link);
}
scrollNav.append(...scrollLinks);
let activeLink;
let navigationFrame = 0;

function updateScrollNav() {
  navigationFrame = 0;
  const marker = Math.min(innerHeight * .27, 190);
  const heroIsVisible = hero.getBoundingClientRect().bottom > 65;
  scrollNav.inert = heroIsVisible;
  const contacts = document.getElementById('contacts');
  scrollConsult.inert = heroIsVisible || (contacts && contacts.getBoundingClientRect().top < innerHeight * .72);

  let next = scrollLinks[0];
  let closestTop = -Infinity;
  for (const link of scrollLinks) {
    const section = document.getElementById(link.hash.slice(1));
    if (!section) continue;
    const top = section.getBoundingClientRect().top;
    if (top <= marker && top >= closestTop) {
      closestTop = top;
      next = link;
    }
  }
  if (next === activeLink) return;
  activeLink?.removeAttribute('aria-current');
  next.setAttribute('aria-current', 'location');
  activeLink = next;

  const navBounds = scrollNav.getBoundingClientRect();
  const linkBounds = next.getBoundingClientRect();
  const gutter = 8;
  if (linkBounds.left < navBounds.left + gutter) {
    scrollNav.scrollBy({ left: linkBounds.left - navBounds.left - gutter, behavior: reduce ? 'instant' : 'smooth' });
  } else if (linkBounds.right > navBounds.right - gutter) {
    scrollNav.scrollBy({ left: linkBounds.right - navBounds.right + gutter, behavior: reduce ? 'instant' : 'smooth' });
  }
}

function scheduleScrollNav() {
  if (!navigationFrame) navigationFrame = requestAnimationFrame(updateScrollNav);
}

addEventListener('scroll', scheduleScrollNav, { passive: true });
addEventListener('resize', scheduleScrollNav);
addEventListener('load', scheduleScrollNav);
scheduleScrollNav();

const dialog=document.getElementById('contactDialog');document.querySelectorAll('.contact').forEach(b=>b.onclick=()=>dialog.showModal());document.getElementById('closeDialog').onclick=()=>dialog.close();dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.close()});document.getElementById('briefForm').onsubmit=async e=>{e.preventDefault();let text=`Здравствуйте! Меня зовут ${document.getElementById('clientName').value}. ${document.getElementById('request').value}`;try{await navigator.clipboard.writeText(text);document.getElementById('formStatus').textContent='Запрос скопирован.'}catch{document.getElementById('formStatus').textContent=text}};
let sectionRevealsStarted=false;
function startSectionReveals(){
 if(sectionRevealsStarted)return;
 sectionRevealsStarted=true;
 const elements=document.querySelectorAll('.dev-heading,.partner-card,.dev-footer');
 if(reduce||!('IntersectionObserver' in window)){elements.forEach(el=>el.classList.add('is-visible'));return;}
 const observer=new IntersectionObserver(entries=>{entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('is-visible');observer.unobserve(entry.target)}})},{threshold:.12,rootMargin:'0px 0px -4% 0px'});
 elements.forEach(el=>observer.observe(el));
}

// A single timeline runs after type and imagery are ready; no layout shifts.
async function revealHero(){
 const heroImage=document.querySelector('.hero-photo>img');
 await Promise.allSettled([document.fonts.ready,heroImage.decode()]);
 if(reduce){document.documentElement.classList.remove('motion-ready');return;}
 const ease='cubic-bezier(.22,1,.36,1)';
 const play=(el,frames,delay,duration=1000)=>el.animate(frames,{duration,delay,easing:ease,fill:'both'});
 const fadeUp=[{opacity:0,transform:'translate3d(0,18px,0)'},{opacity:1,transform:'translate3d(0,0,0)'}];
 play(document.querySelector('.hero-photo'),[{opacity:0,transform:'translate3d(0,16px,0)'},{opacity:1,transform:'translate3d(0,0,0)'}],30,1200);
 play(heroImage,[{transform:'scale(1.065)'},{transform:'scale(1)'}],30,1650);
 play(document.querySelector('.logo'),fadeUp,100,1000);
 document.querySelectorAll('nav .square').forEach((e,i)=>play(e,fadeUp,160+i*75,900));
 document.querySelectorAll('.line-mask>span').forEach((e,i)=>play(e,[{opacity:0,transform:'translate3d(0,110%,0)'},{opacity:1,transform:'translate3d(0,0,0)'}],130+i*120,1150));
 document.querySelectorAll('.photo-copy p').forEach((e,i)=>play(e,fadeUp,500+i*110,1100));
 play(document.querySelector('.consult'),[{opacity:0,clipPath:'inset(0 calc(100% - 45px) 0 0 round 50px)'},{opacity:1,clipPath:'inset(0 0% 0 0 round 50px)'}],230,1250);
 play(document.querySelector('.consult-label'),[{opacity:0,transform:'translateX(-12px)'},{opacity:1,transform:'translateX(0)'}],650,850);
 play(document.querySelector('.select'),fadeUp,470,1100);
 play(document.querySelector('.developers-link'),fadeUp,660,1050);
}
startPreloader();
document.querySelectorAll('.partner-card').forEach(card=>{
 const setOpen=open=>{card.classList.toggle('is-open',open);card.setAttribute('aria-expanded',String(open))};
 card.addEventListener('click',()=>setOpen(!card.classList.contains('is-open')));
 card.addEventListener('mouseenter',()=>card.setAttribute('aria-expanded','true'));
 card.addEventListener('mouseleave',()=>card.setAttribute('aria-expanded',String(card.classList.contains('is-open'))));
 card.addEventListener('focus',()=>card.setAttribute('aria-expanded','true'));
 card.addEventListener('blur',()=>{if(!card.classList.contains('is-open'))card.setAttribute('aria-expanded','false')});
 card.addEventListener('keydown',event=>{if(event.key==='Escape'){setOpen(false);card.blur()}});
});

async function startPreloader(){
 const root=document.documentElement,overlay=document.getElementById('preloader'),main=document.querySelector('main');
 if(!overlay){revealHero();startSectionReveals();return;}
 main.inert=true;
 const bar=overlay.querySelector('[role="progressbar"]'),fill=document.getElementById('preloaderFill'),percent=document.getElementById('preloaderPercent');
 let target=0,displayed=0,frameId,last=performance.now(),finished=false;
 const update=()=>{const now=performance.now(),delta=Math.min(now-last,64);last=now;displayed+=(target-displayed)*(1-Math.exp(-delta/165));if(target===100&&displayed>99.65)displayed=100;fill.style.transform=`scaleX(${displayed/100})`;percent.textContent=Math.floor(displayed)+'%';bar.setAttribute('aria-valuenow',String(Math.floor(displayed)));if(!finished)frameId=requestAnimationFrame(update);};
 update();
 const track=(promise,weight)=>Promise.resolve(promise).catch(()=>{}).finally(()=>{target=Math.min(100,target+weight)});
 const decode=selector=>{const img=document.querySelector(selector);return img?img.decode():Promise.resolve()};
 try{
  const tasks=[track(document.fonts.load('400 16px SF'),15),track(document.fonts.load('500 16px SF'),15),track(document.fonts.load('600 16px SF'),10),track(decode('.preloader-logo'),10),track(decode('.hero-photo>img'),30),track(decode('.expand-photo>img'),20)];
  await Promise.race([Promise.allSettled(tasks),new Promise(resolve=>setTimeout(resolve,8000))]);
  target=100;
  await new Promise(resolve=>{const check=()=>displayed>=100?resolve():requestAnimationFrame(check);check()});
  if(!reduce)await new Promise(resolve=>setTimeout(resolve,180));
  revealHero();
  if(!reduce)await overlay.animate([{transform:'translateY(0)'},{transform:'translateY(-102%)'}],{duration:900,easing:'cubic-bezier(.76,0,.24,1)',fill:'forwards'}).finished;
 }catch{document.documentElement.classList.remove('motion-ready');}
 finally{finished=true;cancelAnimationFrame(frameId);clearTimeout(window.loaderSafety);main.inert=false;root.classList.remove('is-loading');overlay.remove();startSectionReveals();}
}
