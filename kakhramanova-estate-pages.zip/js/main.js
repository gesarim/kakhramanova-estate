const serviceButtons = [
  ...document.querySelectorAll(".service-options [data-service]"),
];
const servicePanels = [...document.querySelectorAll("[data-service-panel]")];
const serviceDetail = document.querySelector("#service-detail");
const requestDialog = document.querySelector(".request-dialog");
const successDialog = document.querySelector(".success-dialog");
const educationDialog = document.querySelector(".education-dialog");
const processSection = document.querySelector("#process");
let requestTopic = "";

serviceButtons.forEach((button) => {
  button.addEventListener("click", () => {
    const selected = button.dataset.service;
    serviceButtons.forEach((item) =>
      item.setAttribute("aria-pressed", String(item === button)),
    );
    servicePanels.forEach((panel) => {
      panel.hidden = panel.dataset.servicePanel !== selected;
    });
    serviceDetail?.classList.add("mobile-open");
    if (window.innerWidth <= 630) {
      requestAnimationFrame(() =>
        serviceDetail?.scrollIntoView({ behavior: "smooth", block: "start" }),
      );
    }
  });
});

document.addEventListener("click", (event) => {
  const target = event.target instanceof Element ? event.target : null;
  const topicLink = target?.closest("[data-request-topic]");
  if (topicLink) requestTopic = topicLink.dataset.requestTopic || "";

  const consultation = target?.closest("[data-open-consultation]");
  if (consultation && !consultation.disabled) {
    const method = consultation.dataset.openConsultation || "phone";
    setMethod(requestDialog.querySelector("form"), method);
    requestDialog.showModal();
  }

  if (target?.closest("[data-open-education]")) educationDialog.showModal();
  if (target?.closest(".request-dialog-header .icon-button"))
    requestDialog.close();
  if (target?.closest("[data-close-success]")) successDialog.close();
});

for (const dialog of [requestDialog, successDialog, educationDialog]) {
  dialog?.addEventListener("click", (event) => {
    if (event.target === dialog) dialog.close();
  });
}

document.querySelectorAll("[data-diploma-toggle]").forEach((button) => {
  button.addEventListener("click", () => {
    const panel = document.getElementById(button.getAttribute("aria-controls"));
    const open = button.getAttribute("aria-expanded") === "true";
    document.querySelectorAll("[data-diploma-toggle]").forEach((item) => {
      item.setAttribute("aria-expanded", "false");
      document.getElementById(item.getAttribute("aria-controls")).hidden = true;
    });
    button.setAttribute("aria-expanded", String(!open));
    panel.hidden = open;
  });
});

function setMethod(form, method) {
  const selected = form.querySelector(
    `input[name="method"][value="${method}"]`,
  );
  if (!selected) return;
  selected.checked = true;
  const input = form.querySelector("[data-contact-input]");
  const label = form.querySelector("[data-contact-label]");
  const responseTime = form.querySelector("[data-response-time]");
  const methods = {
    phone: ["Номер телефона", "+7 (___) ___-__-__", "tel"],
    whatsapp: ["Номер в WhatsApp", "+7 (___) ___-__-__", "tel"],
    telegram: ["Никнейм в Telegram", "@username", "text"],
    max: ["Номер или никнейм в MAX", "Контакт в MAX", "text"],
  };
  const [title, placeholder, type] = methods[method];
  label.firstChild.textContent = title;
  input.type = type;
  input.placeholder = placeholder;
  input.autocomplete = type === "tel" ? "tel" : "off";
  input.value = "";
  responseTime.textContent =
    method === "phone"
      ? "Позвоним в рабочее время: ежедневно с 10:00 до 19:00 по МСК."
      : "Обычно отвечаем в течение часа: ежедневно с 10:00 до 19:00 по МСК.";
}

document.querySelectorAll("[data-request-form]").forEach((form) => {
  const submitUrl = form.dataset.submitUrl?.trim();
  if (submitUrl) form.querySelector("[data-submit-label]").textContent = "Отправить заявку";
  form.querySelectorAll('input[name="method"]').forEach((radio) => {
    radio.addEventListener("change", () => setMethod(form, radio.value));
  });
  form.addEventListener("change", () => {
    form.querySelector("[data-form-status]").textContent = "";
    form.querySelector(".request-copy")?.remove();
  });
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const data = new FormData(form);
    if (!data.has("consent")) return;
    const name = String(data.get("name") || "").trim();
    const contact = String(data.get("contact") || "").trim();
    const comment = String(data.get("comment") || "").trim();
    const method = form.querySelector('input[name="method"]:checked');
    const methodName =
      method?.closest("label")?.querySelector("span")?.textContent || "Звонок";
    const message = [
      `Имя: ${name}`,
      `Способ связи: ${methodName}`,
      `Контакт: ${contact}`,
      requestTopic && `Тема: ${requestTopic}`,
      comment && `Комментарий: ${comment}`,
    ]
      .filter(Boolean)
      .join("\n");
    const status = form.querySelector("[data-form-status]");
    if (!name || !contact) {
      status.textContent = "Укажите имя и контакт для связи.";
      return;
    }
    if (submitUrl) {
      const submitButton = form.querySelector('[type="submit"]');
      submitButton.disabled = true;
      status.textContent = "Отправляем вашу заявку…";
      try {
        const headers = { "Content-Type": "application/json", Accept: "application/json" };
        if (form.dataset.submitNonce) headers["X-WP-Nonce"] = form.dataset.submitNonce;
        const response = await fetch(submitUrl, {
          method: "POST",
          headers,
          body: JSON.stringify({ name, contact, method: method?.value || "phone", comment, topic: requestTopic, consent: true }),
        });
        if (!response.ok) throw new Error(`Отправка не удалась: ${response.status}`);
        form.reset();
        setMethod(form, "phone");
        status.textContent = "";
        requestTopic = "";
        if (requestDialog.open) requestDialog.close();
        successDialog.showModal();
      } catch {
        status.textContent = "Не получилось отправить заявку. Попробуйте ещё раз чуть позже.";
      } finally {
        submitButton.disabled = false;
      }
      return;
    }
    try {
      await navigator.clipboard.writeText(message);
      status.textContent = "Запрос скопирован.";
    } catch {
      status.textContent = "Скопируйте текст запроса вручную.";
      const fallback = document.createElement("textarea");
      fallback.className = "request-copy";
      fallback.readOnly = true;
      fallback.value = message;
      fallback.rows = 5;
      fallback.setAttribute("aria-label", "Текст для копирования");
      form.append(fallback);
    }
  });
});

if (processSection) {
  const measure = () =>
    processSection.style.setProperty(
      "--process-height",
      `${processSection.offsetHeight}px`,
    );
  measure();
  new ResizeObserver(measure).observe(processSection);
}

if (!matchMedia("(prefers-reduced-motion: reduce)").matches) {
  const reveal = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("entered");
          reveal.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.13 },
  );
  document.querySelectorAll(".reveal").forEach((item) => reveal.observe(item));
  document.documentElement.classList.add("motion");
}
