document.documentElement.classList.add("motion-ready", "is-loading");
window.loaderSafety = setTimeout(() => {
  document.documentElement.classList.remove("is-loading", "motion-ready");
  document.querySelector("main")?.removeAttribute("inert");
  document.querySelector("#preloader")?.remove();
}, 12000);
