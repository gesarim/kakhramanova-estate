const dialog = document.getElementById("developerDialog");
const closeButton = document.getElementById("developerDialogClose");
const title = document.getElementById("developerDialogTitle");
const description = document.getElementById("developerDialogDescription");
const image = document.getElementById("developerDialogImage");
const facts = document.getElementById("developerDialogFacts");
let previousFocus = null;
let closeTimer = null;

function closeDeveloperDialog() {
  if (!dialog.open || closeTimer) return;
  dialog.classList.remove("is-visible");
  closeTimer = setTimeout(
    () => {
      dialog.close();
      closeTimer = null;
      previousFocus?.focus();
    },
    matchMedia("(prefers-reduced-motion: reduce)").matches ? 0 : 260,
  );
}

document.querySelectorAll(".partner-logo[data-developer]").forEach((button) => {
  button.addEventListener("click", () => {
    const content = document.getElementById(button.dataset.developer);
    if (!content) return;
    previousFocus = button;
    title.textContent = content.querySelector("h2").textContent;
    description.textContent = content.querySelector("p").textContent;
    image.src = content.querySelector("img").src;
    image.alt = content.querySelector("img").alt;
    facts.replaceChildren(
      ...[...content.querySelectorAll("li")].map((item) =>
        item.cloneNode(true),
      ),
    );
    dialog.showModal();
    requestAnimationFrame(() => dialog.classList.add("is-visible"));
  });
});

closeButton.addEventListener("click", closeDeveloperDialog);
dialog.addEventListener("cancel", (event) => {
  event.preventDefault();
  closeDeveloperDialog();
});
dialog.addEventListener("click", (event) => {
  if (event.target !== dialog) return;
  const rect = dialog.getBoundingClientRect();
  if (
    event.clientX < rect.left ||
    event.clientX > rect.right ||
    event.clientY < rect.top ||
    event.clientY > rect.bottom
  )
    closeDeveloperDialog();
});
