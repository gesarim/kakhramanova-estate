const menuButton = document.querySelector("#blogMenuButton");
const panel = document.querySelector("#blogMenu");
menuButton?.addEventListener("click", () => {
  const open = panel.hidden;
  panel.hidden = !open;
  menuButton.setAttribute("aria-expanded", String(open));
});
document.addEventListener("click", (e) => {
  if (!e.target.closest(".menu-wrap") && panel) panel.hidden = true;
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && panel) panel.hidden = true;
});
const bar = document.querySelector(".floatbar");
const update = () => bar?.classList.toggle("visible", scrollY > 400);
addEventListener("scroll", update, { passive: true });
update();
