const developers = [
  {
    name: 'STONE', image: '01.webp', site: 'https://stone.ru/company',
    description: 'Московский девелопер офисной и жилой недвижимости классов бизнес+ и премиум. Компания развивает проекты с вниманием к архитектуре и городской среде.',
    facts: ['На рынке недвижимости с 2006 года', 'Более 50 проектов в портфеле', 'В портфеле есть бизнес-центры класса А и жилые комплексы']
  },
  {
    name: 'Sminex', image: '02.webp', site: 'https://www.sminex.com/',
    description: 'Sminex создаёт дома высокого класса в Москве. Свой подход компания называет Fine Development: он охватывает архитектуру, материалы и повседневный комфорт жителей.',
    facts: ['Фокус на элитных домах Москвы', 'Фирменный подход — Fine Development', 'Сопровождает клиентов от выбора дома до жизни в нём']
  },
  {
    name: 'Группа ЛСР', image: '03.jpg', site: 'https://www.lsr.ru/',
    description: 'Одна из крупных строительных групп России. Помимо девелопмента, ЛСР занимается строительством и производством материалов.',
    facts: ['Работает с 1993 года', 'Строит жильё разных классов', 'Среди ключевых рынков — Москва и Санкт-Петербург']
  },
  {
    name: 'Мангазея', image: '04.webp', site: 'https://mangazeya.ru/business/business-development',
    description: 'Девелоперское направление группы «Мангазея» развивает жилые и коммерческие проекты в Москве, уделяя внимание архитектуре, планировкам и благоустройству.',
    facts: ['На рынке недвижимости Москвы с 2012 года', 'Работает с жилыми и коммерческими проектами', 'Развивает проекты комплексного освоения территорий']
  },
  {
    name: 'ГК Пионер', image: '05.jpg', site: 'https://pioneer.ru/',
    description: 'PIONEER создаёт жилую и коммерческую недвижимость. В портфеле компании есть городские кварталы, бизнес-центры и сервисные апарт-отели.',
    facts: ['25 лет девелоперской практики', 'Около 40 проектов в портфеле', 'Среди направлений — жильё, офисы и апарт-отели YES']
  },
  {
    name: 'Брусника', image: '06.webp', site: 'https://moskva.brusnika.ru/company/history/',
    description: 'Российский девелопер жилых кварталов. Компания делает акцент на функциональных планировках, общественных пространствах и качестве городской среды.',
    facts: ['Основана в 2004 году', 'Специализируется на многоэтажном жилье', 'Строит в Москве, на Урале и в Сибири']
  },
  {
    name: 'ФСК', image: '07.jpg', site: 'https://fsk.ru/about',
    description: 'Группа компаний полного цикла: от разработки проектов до строительства и управления. В линейке есть жильё и нежилые помещения.',
    facts: ['Строит с 2005 года', 'Реализует проекты в Москве и Московской области', 'Работает в жилом и коммерческом сегментах']
  },
  {
    name: 'MR Group', image: '08.webp', site: 'https://www.mr-group.ru/',
    description: 'Московский девелопер жилой и коммерческой недвижимости. Проекты компании охватывают городские дома, кварталы и офисные пространства.',
    facts: ['Среди жилых проектов — клубный дом FORUM', 'Среди офисных проектов — BELL, SET и ONE', 'Работает с архитектурой и городской средой Москвы']
  },
  {
    name: 'FORMA', image: '09.png', site: 'https://forma.ru/about',
    description: 'Московский девелопер концептуальных кварталов бизнес- и премиум-класса. Компания соединяет авторскую архитектуру, инфраструктуру и характер локации.',
    facts: ['Проекты расположены в Москве', 'Фокус на бизнес- и премиум-классе', 'В портфеле есть жильё и коммерческие помещения']
  },
  {
    name: 'Level Group', image: '10.jpg', site: 'https://level.ru/',
    description: 'Девелопер жилой и коммерческой недвижимости в Москве и Подмосковье. В своих проектах компания уделяет внимание архитектуре и повседневным сценариям жителей.',
    facts: ['Строит в Москве и Московской области', 'Предлагает жилые и коммерческие объекты', 'Работает с проектами разных форматов']
  },
  {
    name: 'Upside Development', image: '11.jpg', site: 'https://upside.ru/',
    description: 'Девелопер полного цикла, который объединяет проектирование, строительство и управление недвижимостью внутри одной структуры.',
    facts: ['15 лет опыта', 'В структуре есть собственное проектное бюро', 'Также работают генеральный подрядчик и управляющая компания']
  },
  {
    name: 'Галс-Девелопмент', image: '12.webp', site: 'https://hals-development.ru/',
    description: 'Компания создаёт жилые и коммерческие объекты. В её истории — знаковые проекты в Москве, включая кварталы и объекты городской инфраструктуры.',
    facts: ['История компании началась в 1994 году', 'Развивает жилую и коммерческую недвижимость', 'Среди реализованных объектов — ЦДМ на Лубянке и Wine House']
  },
  {
    name: 'Донстрой', image: '13.jpg', site: 'https://donstroy.moscow/about/',
    description: 'Московский девелопер жилой недвижимости: от крупных городских кварталов до камерных домов в центральных районах.',
    facts: ['Работает с 1994 года', 'Строит в Москве', 'В портфеле есть проекты бизнес-, премиум- и делюкс-класса']
  },
  {
    name: 'Группа Аквилон', image: '14.jpg', site: 'https://msk.group-akvilon.ru/about/',
    description: 'Девелопер федерального масштаба с проектами жилой и коммерческой недвижимости в нескольких регионах России.',
    facts: ['Работает с 2003 года', 'Более 200 построенных объектов', 'Среди городов присутствия — Москва и Санкт-Петербург']
  },
  {
    name: 'VESPER', image: '15.jpg', site: 'https://www.vespermoscow.com/about-us/',
    description: 'Девелопер клубных домов и недвижимости класса de luxe. В проектах компания сочетает современную архитектуру с бережным отношением к исторической среде.',
    facts: ['В портфеле 22 объекта в Москве и Европе', 'Специализация — сегмент de luxe', 'Работает с международными архитектурными и дизайнерскими командами']
  },
  {
    name: 'Villagio Estate', image: '16.jpg', site: 'https://villagio.ru/',
    description: 'Компания занимается элитной загородной недвижимостью: коттеджными посёлками, домами и земельными участками в Подмосковье.',
    facts: ['Основное направление — загородные дома и посёлки', 'Среди локаций — Новая Рига и Подмосковье', 'На сайте представлены покупка, продажа и аренда']
  },
  {
    name: 'Capital Group', image: '17.webp', site: 'https://www.capitalgroup.ru/eng/company/aboutcompany',
    description: 'Девелопер знаковых для Москвы жилых и коммерческих объектов. Компания работает со сложными градостроительными задачами и высотным строительством.',
    facts: ['Более 30 лет на рынке', 'Строит жильё, бизнес-центры и многофункциональные комплексы', 'Среди направлений — небоскрёбы и комплексное развитие территорий']
  },
  {
    name: 'Tekta Group', image: '18.jpg', site: 'https://tekta.ru/about',
    description: 'Девелоперская компания полного цикла. В Москве ТЕКТА реализует жилые проекты бизнес- и премиум-класса.',
    facts: ['На рынке недвижимости с 1999 года', 'Портфель проектов — более 800 тыс. м²', 'Среди реализованных проектов — кварталы NOW и EVER']
  },
  {
    name: 'Кортрос', image: '19.webp', site: 'https://kortros.ru/company/our-projects',
    description: 'Девелопер, который работает с жилыми проектами и комплексным развитием территорий в Москве и регионах России.',
    facts: ['Начал работу в 2005 году', 'Один из ранних проектов — район «Академический» в Екатеринбурге', 'Строит в Москве, Екатеринбурге, Перми и Калининграде']
  }
];

const dialog = document.getElementById('developerDialog');
const closeButton = document.getElementById('developerDialogClose');
const title = document.getElementById('developerDialogTitle');
const description = document.getElementById('developerDialogDescription');
const image = document.getElementById('developerDialogImage');
const facts = document.getElementById('developerDialogFacts');
let previousFocus = null;
let closeTimer = null;

function closeDeveloperDialog() {
  if (!dialog.open || closeTimer) return;
  dialog.classList.remove('is-visible');
  closeTimer = window.setTimeout(() => {
    dialog.close();
    closeTimer = null;
    previousFocus?.focus();
  }, window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : 260);
}

document.querySelectorAll('.partner-logo[data-developer]').forEach(button => {
  button.addEventListener('click', () => {
    const developer = developers[Number(button.dataset.developer)];
    if (!developer) return;
    previousFocus = button;
    title.textContent = developer.name;
    description.textContent = developer.description;
    image.src = `./reference/assets/developer-photos/${developer.image}`;
    image.alt = `Проект компании ${developer.name}`;
    facts.replaceChildren(...developer.facts.map(fact => {
      const item = document.createElement('li');
      item.textContent = fact;
      return item;
    }));
    dialog.showModal();
    requestAnimationFrame(() => dialog.classList.add('is-visible'));
  });
});

closeButton.addEventListener('click', closeDeveloperDialog);
dialog.addEventListener('cancel', event => {
  event.preventDefault();
  closeDeveloperDialog();
});
dialog.addEventListener('click', event => {
  if (event.target !== dialog) return;
  const rect = dialog.getBoundingClientRect();
  if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) closeDeveloperDialog();
});
